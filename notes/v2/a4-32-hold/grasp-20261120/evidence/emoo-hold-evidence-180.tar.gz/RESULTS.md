# v2.0 integration evaluation

60 episodes/group, 180 total; GPU: NVIDIA L40; dtype: torch.bfloat16.

| Group | Peak boxes | Final boxes | Success | Four-box retention | Mean / P95 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| A4-32 | 2.817 | 2.067 | 10/60 (16.7%) | 10/15 | 212.0 / 237.3 |
| A4-32-HOLD | 2.817 | 2.067 | 10/60 (16.7%) | 10/15 | 212.5 / 238.2 |
| A4-32-LOCAL-HOLD | 2.850 | 2.100 | 11/60 (18.3%) | 11/16 | 212.5 / 237.4 |

Paired differences against the fresh A4-32 baseline, with scene-bootstrap 95% intervals:

| Group | Peak delta [95% CI] | Final delta [95% CI] | Success delta [95% CI], pp |
| --- | ---: | ---: | ---: |
| A4-32-HOLD | +0.000 [-0.050, +0.050] | -0.000 [-0.150, +0.183] | +0.000 [-5.000, +5.000] |
| A4-32-LOCAL-HOLD | +0.033 [+0.000, +0.083] | +0.033 [-0.100, +0.217] | +1.667 [+0.000, +5.000] |

These are paired development results with multiple exploratory comparisons. Do not treat a selected best variant as independently confirmed. Peak four boxes and official success are separate metrics.
